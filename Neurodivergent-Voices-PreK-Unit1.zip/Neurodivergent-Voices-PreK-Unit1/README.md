# Neurodivergent Voices Academy — Pre-K Unit 1

This package adds a GitHub Pages-ready Pre-K Unit 1 to the Neurodivergent Voices site.

## Included
- Academy landing page
- Pre-K Unit 1 dashboard
- Weeks 1–4
- 36 interactive lessons total
- 9 learning areas per week
- Immediate answer feedback
- Lesson completion tracking with localStorage
- Break/regulation button
- Responsive accessible layout
- SEO title and meta description
- Flexible response-mode language

## Upload
Copy the `academy` folder into the root of your existing GitHub repository:

`fragrancefreesoap-maker/Neurodivergent-Voices`

Then commit and push the files.

## Expected pages
- `/academy/`
- `/academy/prek/`
- `/academy/prek/week-1.html`
- `/academy/prek/week-2.html`
- `/academy/prek/week-3.html`
- `/academy/prek/week-4.html`

The exact live URL will be:

`https://fragrancefreesoap-maker.github.io/Neurodivergent-Voices/academy/prek/`

after GitHub Pages finishes deploying.
